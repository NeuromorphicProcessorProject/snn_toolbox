# -*- coding: utf-8 -*-
"""
Redirect brian_target_sim to pyNN_target_sim.

Created on Mon May 23 12:04:06 2016

@author: rbodo
"""

from snntoolbox.target_simulators.pyNN_target_sim import SNN
